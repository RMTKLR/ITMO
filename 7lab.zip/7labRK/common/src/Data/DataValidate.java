package Data;
@FunctionalInterface
public interface DataValidate {
    boolean dataValidate();
}
