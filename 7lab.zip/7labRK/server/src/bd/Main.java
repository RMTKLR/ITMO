package bd;

import Data.Flat;

import java.sql.*;
import java.util.ArrayDeque;

public class Main {
    public static void main(String[] args) throws SQLException {
        /*BdConnection bd = new BdConnection();
        Connection cnt = bd.getConnection();
        BdMain bdCntr = new BdMain();
        ArrayDeque<Flat> setT = bdCntr.getAllData(cnt);

        setT.stream().forEach(p -> System.out.println(p.toString()));*/

    }
}
