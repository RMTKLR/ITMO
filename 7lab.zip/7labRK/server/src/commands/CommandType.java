package commands;

public enum CommandType {
    ARGUMENT,
    NON_ARGUMENT,
    ARGUMENT_WITH_FLAT,
    BOTH_ARGUMENT_AND_ARGUMENT_FLAT,
    ARGUMENT_WITH_HOUSE;
}
