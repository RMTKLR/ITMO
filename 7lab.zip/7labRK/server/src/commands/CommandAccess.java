package commands;

public enum CommandAccess {
    NORMAL,
    SERVER;
}
